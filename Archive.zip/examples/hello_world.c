#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main() {
    printf("Hello from SimpleContainer!\n");
    return 0;
}